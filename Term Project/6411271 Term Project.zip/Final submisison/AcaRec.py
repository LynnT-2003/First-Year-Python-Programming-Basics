#Id: 6411271
#Name: Lynn Thit Nyi Nyi

import AcademicModule as main
main.run()
